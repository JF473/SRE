
  # AR Surgery Visualizer Prototype

  This is a code bundle for AR Surgery Visualizer Prototype. The original project is available at https://www.figma.com/design/pu0WFN1mNt5dAxPtzv0B8v/AR-Surgery-Visualizer-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  